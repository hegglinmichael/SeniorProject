
#include "BaseClass.h"

using namespace nanpy;

SlimArray <BaseClass*> Register::classes;
