from nanpy.arduinoboard import ArduinoObject
from nanpy.arduinoboard import arduinoobjectmethod

class Lcd(ArduinoObject):
    cfg_h_name = 'USE_LiquidCrystal'

    def __init__(self, pins, begin, connection=None):
        '''
        :param pins: [rs, enable, d4, d5, d6, d7]
        :param begin: [cols, rows]
        '''
        ArduinoObject.__init__(self, connection=connection)
        self.id = self.call('new', pins, begin)

    @arduinoobjectmethod
    def printString(self, value, col = None, row = None):
        pass

    @arduinoobjectmethod
    def setCursor(self, col, row):
        pass

    @arduinoobjectmethod
    def autoscroll(self):
        pass

    @arduinoobjectmethod
    def noAutoscroll(self):
        pass

    @arduinoobjectmethod
    def clear(self):
        pass

    @arduinoobjectmethod
    def createChar(self, num, data):
        pass

    @arduinoobjectmethod
    def write(self, data):
        pass
